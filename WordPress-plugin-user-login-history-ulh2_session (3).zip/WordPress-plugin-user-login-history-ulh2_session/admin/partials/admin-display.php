<?php
/**
 * The dashboard-specific functionality of the plugin.
 *
 * @link       https://github.com/faiyazalam
 *
 * @package    User_Login_History
 * @subpackage User_Login_History/admin/partials
 * @author     Er Faiyaz Alam
 */
?>
<?php // Silence is golden